'use client'
import { useState, useEffect, useMemo } from 'react'
import { api, fmt, ORG_ID } from '@/lib/client'

interface Rep {
  epay_salesperson: string
  storeops_name: string
  store: string
  tier: number
  kpis_met: number
  total_kpis: number
  premium_acts: number
  byod_acts: number
  upgrade_acts: number
  acc_comm: number
  setup_fee_comm: number
  trade_in_comm: number
  acima_comm: number
  subtotal: number
  total_payout: number
}

const TABS = [
  { id: 'breakdown', label: '👥 Rep Breakdown' },
  { id: 'individual', label: '📄 Individual Rep' },
  { id: 'compensation', label: '💰 Compensation by Line' },
]

export default function ReportsPage() {
  const [period] = useState('April 2026')
  const [reps, setReps] = useState<Rep[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState('breakdown')
  const [selectedRep, setSelectedRep] = useState('')
  const [filterRep, setFilterRep] = useState('')
  const [filterStore, setFilterStore] = useState('')

  useEffect(() => {
    api(`/api/v1/commcalc/commissions/${encodeURIComponent(period)}?org_id=${ORG_ID}`)
      .then(setReps).catch(console.error).finally(() => setLoading(false))
  }, [period])

  const repList  = useMemo(() => [...new Set(reps.map(r => r.epay_salesperson))].sort(), [reps])
  const storeList = useMemo(() => [...new Set(reps.map(r => r.store).filter(Boolean))].sort(), [reps])
  const totalPayout = reps.reduce((s, r) => s + (r.total_payout || 0), 0)

  const filtered = reps.filter(r => {
    if (filterRep   && r.epay_salesperson !== filterRep) return false
    if (filterStore && !r.store?.includes(filterStore))   return false
    return true
  })

  const currentRep = reps.find(r => r.epay_salesperson === selectedRep) || reps[0]

  function TierBadge({ tier }: { tier: number }) {
    const pct = Math.round((tier || 0) * 100)
    const cls = pct >= 100 ? 'badge-green' : pct >= 75 ? 'badge-amber' : 'badge-red'
    return <span className={`badge ${cls}`}>{pct}%</span>
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, margin: 0 }}>Reports</h1>
          <p style={{ color: 'var(--text2)', fontSize: 14, margin: '4px 0 0' }}>
            {period} · {reps.length} reps · Total: <strong style={{ color: 'var(--accent)' }}>{fmt(totalPayout)}</strong>
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary" onClick={() => {
            const csv = ['Rep,Store,Tier,KPIs,PA,BA,UA,Acc GP,Subtotal,Payout']
            reps.forEach(r => csv.push(`"${r.epay_salesperson}","${r.store}",${Math.round(r.tier*100)}%,${r.kpis_met}/${r.total_kpis},${r.premium_acts},${r.byod_acts},${r.upgrade_acts},${r.acc_comm?.toFixed(2)},${r.subtotal?.toFixed(2)},${r.total_payout?.toFixed(2)}`))
            const a = document.createElement('a'); a.href = 'data:text/csv,' + encodeURIComponent(csv.join('\n'))
            a.download = `commissions-${period.replace(' ','-')}.csv`; a.click()
          }}>
            📥 CSV
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, background: 'var(--surface2)', padding: 4, borderRadius: 10, width: 'fit-content' }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} className="btn" style={{
            background: tab === t.id ? 'white' : 'transparent',
            color: tab === t.id ? 'var(--accent)' : 'var(--text2)',
            boxShadow: tab === t.id ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
            fontSize: 13,
          }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Rep Breakdown */}
      {tab === 'breakdown' && (
        <div>
          <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
            <select className="select" value={filterRep} onChange={e => setFilterRep(e.target.value)}>
              <option value="">All reps</option>
              {repList.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
            <select className="select" value={filterStore} onChange={e => setFilterStore(e.target.value)}>
              <option value="">All stores</option>
              {storeList.map(s => <option key={s} value={s}>{s.substring(0, 40)}</option>)}
            </select>
            {(filterRep || filterStore) && (
              <button className="btn btn-secondary" onClick={() => { setFilterRep(''); setFilterStore('') }}>
                ✕ Clear
              </button>
            )}
            <span style={{ marginLeft: 'auto', fontSize: 13, color: 'var(--text2)', alignSelf: 'center' }}>
              {filtered.length} of {reps.length} rows
            </span>
          </div>

          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Rep</th>
                  <th>Store</th>
                  <th>Tier</th>
                  <th>KPIs</th>
                  <th>PA</th><th>BA</th><th>UA</th>
                  <th style={{ textAlign: 'right' }}>ACC GP</th>
                  <th style={{ textAlign: 'right' }}>ACIMA</th>
                  <th style={{ textAlign: 'right' }}>Subtotal</th>
                  <th style={{ textAlign: 'right' }}>Payout</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={11} style={{ textAlign: 'center', padding: 40 }}>
                    <div className="spinner" style={{ margin: '0 auto' }} />
                  </td></tr>
                ) : filtered.length === 0 ? (
                  <tr><td colSpan={11} style={{ textAlign: 'center', color: 'var(--text3)', padding: 40 }}>
                    No data. Upload files and run calculation.
                  </td></tr>
                ) : filtered.map((r, i) => (
                  <tr key={i}>
                    <td>
                      <button
                        style={{ background: 'none', border: 'none', cursor: 'pointer', fontWeight: 500,
                          color: 'var(--accent)', textDecoration: 'underline', fontSize: 13, padding: 0 }}
                        onClick={() => { setSelectedRep(r.epay_salesperson); setTab('individual') }}
                      >
                        {r.storeops_name || r.epay_salesperson}
                      </button>
                    </td>
                    <td style={{ color: 'var(--text3)', fontSize: 12 }}>{r.store?.substring(0, 25)}</td>
                    <td><TierBadge tier={r.tier} /></td>
                    <td style={{ fontSize: 12 }}>{r.kpis_met}/{r.total_kpis}</td>
                    <td>{r.premium_acts}</td>
                    <td>{r.byod_acts}</td>
                    <td>{r.upgrade_acts}</td>
                    <td style={{ textAlign: 'right' }}>{fmt(r.acc_comm)}</td>
                    <td style={{ textAlign: 'right', color: r.acima_comm > 0 ? '#7c3aed' : 'var(--text3)' }}>
                      {r.acima_comm > 0 ? fmt(r.acima_comm) : '—'}
                    </td>
                    <td style={{ textAlign: 'right' }}>{fmt(r.subtotal)}</td>
                    <td style={{ textAlign: 'right', fontWeight: 700, color: 'var(--accent)' }}>{fmt(r.total_payout)}</td>
                  </tr>
                ))}
              </tbody>
              {filtered.length > 0 && (
                <tfoot>
                  <tr style={{ background: 'var(--surface2)', fontWeight: 700 }}>
                    <td colSpan={10} style={{ textAlign: 'right', paddingRight: 8, color: 'var(--text2)' }}>Total:</td>
                    <td style={{ textAlign: 'right', color: 'var(--accent)' }}>
                      {fmt(filtered.reduce((s, r) => s + r.total_payout, 0))}
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      )}

      {/* Individual Rep */}
      {tab === 'individual' && (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
            <select className="select" value={selectedRep} onChange={e => setSelectedRep(e.target.value)}>
              <option value="">Select rep...</option>
              {repList.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>

          {currentRep ? (
            <div>
              {/* Summary cards */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 20 }}>
                <div className="card" style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: 28, fontWeight: 700, color: 'var(--accent)' }}>{fmt(currentRep.total_payout)}</div>
                  <div style={{ color: 'var(--text2)', fontSize: 12 }}>Total Payout</div>
                </div>
                <div className="card" style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: 28, fontWeight: 700 }}>{fmt(currentRep.subtotal)}</div>
                  <div style={{ color: 'var(--text2)', fontSize: 12 }}>Subtotal (pre-tier)</div>
                </div>
                <div className="card" style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: 28, fontWeight: 700 }}>
                    <span style={{ color: currentRep.tier >= 1 ? '#16a34a' : currentRep.tier >= 0.75 ? '#d97706' : '#dc2626' }}>
                      {Math.round((currentRep.tier || 0) * 100)}%
                    </span>
                  </div>
                  <div style={{ color: 'var(--text2)', fontSize: 12 }}>Tier Multiplier · {currentRep.kpis_met}/{currentRep.total_kpis} KPIs</div>
                </div>
              </div>

              {/* Line items table */}
              <div className="card" style={{ padding: 0 }}>
                <table>
                  <thead>
                    <tr>
                      <th>Item</th>
                      <th style={{ textAlign: 'right' }}>Count</th>
                      <th style={{ textAlign: 'right' }}>Rate</th>
                      <th style={{ textAlign: 'right' }}>Commission</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Premium Activations</td>
                      <td style={{ textAlign: 'right' }}>{currentRep.premium_acts}</td>
                      <td style={{ textAlign: 'right', color: 'var(--text3)', fontSize: 12 }}>per act</td>
                      <td style={{ textAlign: 'right', fontWeight: 600 }}>{fmt(currentRep.premium_acts * 5)}</td>
                    </tr>
                    <tr>
                      <td>BYOD Activations</td>
                      <td style={{ textAlign: 'right' }}>{currentRep.byod_acts}</td>
                      <td style={{ textAlign: 'right', color: 'var(--text3)', fontSize: 12 }}>per act</td>
                      <td style={{ textAlign: 'right', fontWeight: 600 }}>{fmt(currentRep.byod_acts * 6)}</td>
                    </tr>
                    <tr>
                      <td>Device Upgrades</td>
                      <td style={{ textAlign: 'right' }}>{currentRep.upgrade_acts}</td>
                      <td style={{ textAlign: 'right', color: 'var(--text3)', fontSize: 12 }}>per act</td>
                      <td style={{ textAlign: 'right', fontWeight: 600 }}>{fmt(currentRep.upgrade_acts * 5)}</td>
                    </tr>
                    <tr>
                      <td>Accessories (10% GP)</td>
                      <td style={{ textAlign: 'right', color: 'var(--text3)', fontSize: 12 }}>GP</td>
                      <td style={{ textAlign: 'right', color: 'var(--text3)', fontSize: 12 }}>10% GP</td>
                      <td style={{ textAlign: 'right', fontWeight: 600 }}>{fmt(currentRep.acc_comm)}</td>
                    </tr>
                    <tr>
                      <td>Setup Fees (10% GP)</td>
                      <td style={{ textAlign: 'right', color: 'var(--text3)', fontSize: 12 }}>GP</td>
                      <td style={{ textAlign: 'right', color: 'var(--text3)', fontSize: 12 }}>10% GP</td>
                      <td style={{ textAlign: 'right', fontWeight: 600 }}>{fmt(currentRep.setup_fee_comm)}</td>
                    </tr>
                    <tr>
                      <td>Trade-In SPIFF</td>
                      <td style={{ textAlign: 'right', color: 'var(--text3)', fontSize: 12 }}>—</td>
                      <td style={{ textAlign: 'right', color: 'var(--text3)', fontSize: 12 }}>per trade</td>
                      <td style={{ textAlign: 'right', fontWeight: 600 }}>{fmt(currentRep.trade_in_comm)}</td>
                    </tr>
                    {(currentRep.acima_comm || 0) > 0 && (
                      <tr>
                        <td>ACIMA Financing SPIFF</td>
                        <td style={{ textAlign: 'right', color: 'var(--text3)', fontSize: 12 }}>
                          {Math.round((currentRep.acima_comm || 0) / 25)} txns
                        </td>
                        <td style={{ textAlign: 'right', color: 'var(--text3)', fontSize: 12 }}>$25 each</td>
                        <td style={{ textAlign: 'right', fontWeight: 600, color: '#7c3aed' }}>{fmt(currentRep.acima_comm)}</td>
                      </tr>
                    )}
                    <tr style={{ background: 'var(--surface2)', fontWeight: 700 }}>
                      <td colSpan={3}>Subtotal</td>
                      <td style={{ textAlign: 'right' }}>{fmt(currentRep.subtotal)}</td>
                    </tr>
                    <tr style={{ fontWeight: 700 }}>
                      <td colSpan={3}>× {Math.round((currentRep.tier || 0) * 100)}% Tier</td>
                      <td style={{ textAlign: 'right', color: 'var(--accent)' }}>{fmt(currentRep.total_payout)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: 60, color: 'var(--text3)' }}>
              Select a rep to view their commission breakdown
            </div>
          )}
        </div>
      )}

      {/* Compensation by Line */}
      {tab === 'compensation' && (
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Rep</th>
                <th style={{ textAlign: 'right' }}>Premium</th>
                <th style={{ textAlign: 'right' }}>BYOD</th>
                <th style={{ textAlign: 'right' }}>Upgrades</th>
                <th style={{ textAlign: 'right' }}>Accessories</th>
                <th style={{ textAlign: 'right' }}>Setup Fees</th>
                <th style={{ textAlign: 'right' }}>Trade-Ins</th>
                <th style={{ textAlign: 'right' }}>ACIMA</th>
                <th style={{ textAlign: 'right' }}>Subtotal</th>
                <th style={{ textAlign: 'right' }}>Payout</th>
              </tr>
            </thead>
            <tbody>
              {reps.map((r, i) => (
                <tr key={i}>
                  <td style={{ fontWeight: 500 }}>{r.storeops_name || r.epay_salesperson}</td>
                  <td style={{ textAlign: 'right' }}>{fmt(r.premium_acts * 5)}</td>
                  <td style={{ textAlign: 'right' }}>{fmt(r.byod_acts * 6)}</td>
                  <td style={{ textAlign: 'right' }}>{fmt(r.upgrade_acts * 5)}</td>
                  <td style={{ textAlign: 'right' }}>{fmt(r.acc_comm)}</td>
                  <td style={{ textAlign: 'right' }}>{fmt(r.setup_fee_comm)}</td>
                  <td style={{ textAlign: 'right' }}>{fmt(r.trade_in_comm)}</td>
                  <td style={{ textAlign: 'right', color: r.acima_comm > 0 ? '#7c3aed' : 'var(--text3)' }}>
                    {r.acima_comm > 0 ? fmt(r.acima_comm) : '—'}
                  </td>
                  <td style={{ textAlign: 'right' }}>{fmt(r.subtotal)}</td>
                  <td style={{ textAlign: 'right', fontWeight: 700, color: 'var(--accent)' }}>{fmt(r.total_payout)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
